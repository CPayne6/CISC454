Chris Payne, chris.payne@queensu.ca, 20009392
Alec Glover, 15aeg1@queensu.ca, 20009924
