Chris Payne, 20009392
Alec Glover, 20009924

Novel Feature 1:

The missiles will expload and then impload after they have reached their destination. This was done by modifying state.cpp and circle.h.

Novel Feature 2: 

The missile silo has a barrel that aims at the location of the mouse when it fires a missile. This was done by modifying the silo.h file.


In addition to these features, The missiles were altered to be a fixed length for an enhanced experience.